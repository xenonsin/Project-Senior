﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor.Versioning
{
    public class IconInfo
    {
        public string key;
        public string path;
    }
}
