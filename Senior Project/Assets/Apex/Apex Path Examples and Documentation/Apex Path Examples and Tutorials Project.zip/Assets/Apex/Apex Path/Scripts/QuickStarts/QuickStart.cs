﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.QuickStarts
{
    using UnityEngine;

    public static class QuickStart
    {
        //public static GameObject Apply<T>(GameObject target) where T : QuickStartBase, new()
        //{
        //    var qs = new T();
        //    return qs.Setup(target);
        //}
    }
}
